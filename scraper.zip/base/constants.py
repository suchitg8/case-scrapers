SUCCESS = 200
NOT_FOUND = 400
INTERNAL_ERROR = 500
SCRAPER_API = 'http://api.scraperapi.com/?api_key=1fb9de8fb8df74199f688fe2588d18a4&url='