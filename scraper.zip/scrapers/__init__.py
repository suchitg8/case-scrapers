from .az_maricopa import ScraperAZMaricopaSuperior
from .az_jmaricopa import ScraperAZMaricopaJustice
from .ca_riverside import ScraperCARiversideSuperior
from .ca_san_diego import ScraperCASanDiegoSuperior
from .ca_santa_clara import ScraperCASantaClaraSuperior
from .ga_fulton import ScraperGAFultonSuperior
from .maryland import ScraperMDCourt
from .tx_travis import ScraperTXTravisSuperior
from .missouri import ScraperMOCourt
from .il_johnson import ScraperILJohnsonSuperior

